
<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die('ID pengumuman tidak valid.');
}

$stmt = mysqli_prepare(
    $koneksi,
    "DELETE FROM pengumuman_sekolah WHERE id_pengumuman = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    header('Location: index.php');
    exit;
}

mysqli_stmt_close($stmt);
die('Gagal menghapus pengumuman.');
?>
