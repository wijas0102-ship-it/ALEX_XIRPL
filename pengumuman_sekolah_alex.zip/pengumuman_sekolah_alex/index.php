
<?php
include 'koneksi.php';

function aman($teks) {
    return htmlspecialchars($teks ?? '', ENT_QUOTES, 'UTF-8');
}

$cari = trim($_GET['cari'] ?? '');

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT * FROM pengumuman_sekolah
     WHERE judul LIKE ?
     ORDER BY tanggal_terbit DESC"
);

$kata = "%$cari%";
mysqli_stmt_bind_param($stmt, "s", $kata);
mysqli_stmt_execute($stmt);

$data = mysqli_stmt_get_result($stmt);

$hasilTotal = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS jumlah FROM pengumuman_sekolah"
);

$total = mysqli_fetch_assoc($hasilTotal)['jumlah'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InfoSekolah - Pengumuman Siswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h2>🎓 InfoSekolah</h2>
    <p>Sistem Informasi Pengumuman Siswa</p>
</div>

<div class="container">

    <div class="header">
        <div>
            <h2>Daftar Pengumuman</h2>
            <p>Kelola informasi dan pengumuman sekolah.</p>
        </div>

        <a href="tambah.php" class="btn btn-primary">
            + Tambah Pengumuman
        </a>
    </div>

    <div class="card">
        <p>Total Pengumuman</p>
        <h2><?= (int)$total ?> Pengumuman</h2>
    </div>

    <div class="card">
        <form method="GET">
            <label for="cari">Cari Pengumuman</label>

            <input
                type="search"
                id="cari"
                name="cari"
                placeholder="Masukkan judul pengumuman..."
                value="<?= aman($cari) ?>"
            >

            <button type="submit" class="btn btn-primary">
                Cari
            </button>

            <a href="index.php" class="btn btn-edit">
                Reset
            </a>
        </form>
    </div>

    <div class="card">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Judul dan Isi</th>
                        <th>Kategori</th>
                        <th>Tanggal Terbit</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                <?php $no = 1; ?>

                <?php while ($row = mysqli_fetch_assoc($data)) { ?>
                    <tr>
                        <td><?= $no++ ?></td>

                        <td>
                            <strong>
                                <?= aman($row['judul']) ?>
                            </strong>
                            <br><br>
                            <?= nl2br(aman($row['isi'])) ?>
                        </td>

                        <td><?= aman($row['kategori']) ?></td>

                        <td><?= aman($row['tanggal_terbit']) ?></td>

                        <td>
                            <div class="aksi">
                                <a
                                    href="edit.php?id=<?= (int)$row['id_pengumuman'] ?>"
                                    class="btn btn-edit"
                                >
                                    Edit
                                </a>

                                <form
                                    action="hapus.php"
                                    method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus pengumuman ini?')"
                                >
                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= (int)$row['id_pengumuman'] ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="btn btn-delete"
                                    >
                                        Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php } ?>

                <?php if (mysqli_num_rows($data) === 0) { ?>
                    <tr>
                        <td colspan="5">
                            Pengumuman tidak ditemukan.
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
?>

