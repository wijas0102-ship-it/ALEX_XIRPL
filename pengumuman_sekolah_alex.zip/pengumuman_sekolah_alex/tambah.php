
<?php
include 'koneksi.php';

function aman($teks) {
    return htmlspecialchars($teks ?? '', ENT_QUOTES, 'UTF-8');
}

$judul = '';
$isi = '';
$kategori = '';
$tanggal = '';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $tanggal = $_POST['tanggal_terbit'] ?? '';

    if ($judul === '' || $isi === '' ||
        $kategori === '' || $tanggal === '') {
        $pesan = 'Semua kolom wajib diisi.';
    } elseif (
        strlen($judul) > 100 ||
        strlen($kategori) > 30 ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) ||
        !checkdate(
            (int)substr($tanggal, 5, 2),
            (int)substr($tanggal, 8, 2),
            (int)substr($tanggal, 0, 4)
        )
    ) {
        $pesan = 'Periksa kembali judul, kategori, dan tanggal.';
    } else {
        $stmt = mysqli_prepare(
            $koneksi,
            "INSERT INTO pengumuman_sekolah
            (judul, isi, kategori, tanggal_terbit)
            VALUES (?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssss",
            $judul,
            $isi,
            $kategori,
            $tanggal
        );

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header('Location: index.php');
            exit;
        }

        $pesan = 'Gagal menyimpan pengumuman.';
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengumuman - InfoSekolah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h2>🎓 InfoSekolah</h2>
    <p>Sistem Informasi Pengumuman Siswa</p>
</div>

<div class="container">
    <div class="header">
        <h2>Tambah Pengumuman</h2>
    </div>

    <div class="card">

        <?php if ($pesan !== '') { ?>
            <div class="alert"><?= aman($pesan) ?></div>
        <?php } ?>

        <form method="POST">
            <label for="judul">Judul Pengumuman</label>
            <input
                type="text"
                id="judul"
                name="judul"
                maxlength="100"
                value="<?= aman($judul) ?>"
                placeholder="Masukkan judul pengumuman"
                required
            >

            <label for="isi">Isi Pengumuman</label>
            <textarea
                id="isi"
                name="isi"
                placeholder="Tuliskan isi pengumuman..."
                required
            ><?= aman($isi) ?></textarea>

            <label for="kategori">Kategori</label>
            <select id="kategori" name="kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <option value="Akademik"
                    <?= $kategori === 'Akademik' ? 'selected' : '' ?>>
                    Akademik
                </option>
                <option value="Kegiatan"
                    <?= $kategori === 'Kegiatan' ? 'selected' : '' ?>>
                    Kegiatan
                </option>
                <option value="Penting"
                    <?= $kategori === 'Penting' ? 'selected' : '' ?>>
                    Penting
                </option>
                <option value="Lainnya"
                    <?= $kategori === 'Lainnya' ? 'selected' : '' ?>>
                    Lainnya
                </option>
            </select>

            <label for="tanggal_terbit">Tanggal Terbit</label>
            <input
                type="date"
                id="tanggal_terbit"
                name="tanggal_terbit"
                value="<?= aman($tanggal) ?>"
                required
            >

            <button type="submit" class="btn btn-primary">
                Simpan Pengumuman
            </button>

            <a href="index.php" class="btn btn-edit">
                Kembali
            </a>
        </form>

    </div>
</div>

</body>
</html>












