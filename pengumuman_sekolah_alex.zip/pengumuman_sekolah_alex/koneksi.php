<?php
$koneksi = mysqli_connect(
    "localhost",
    "root",
    "",
    "pengumuman_sekolah_alex"
);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>