
<?php
include 'koneksi.php';

function aman($teks) {
    return htmlspecialchars($teks ?? '', ENT_QUOTES, 'UTF-8');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die('ID pengumuman tidak valid.');
}

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT * FROM pengumuman_sekolah WHERE id_pengumuman = ?"
);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$row) {
    die('Pengumuman tidak ditemukan.');
}

$judul = $row['judul'];
$isi = $row['isi'];
$kategori = $row['kategori'];
$tanggal = $row['tanggal_terbit'];
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $tanggal = $_POST['tanggal_terbit'] ?? '';

    if ($judul === '' || $isi === '' ||
        $kategori === '' || $tanggal === '') {
        $pesan = 'Semua kolom wajib diisi.';
    } elseif (
        strlen($judul) > 100 ||
        strlen($kategori) > 30 ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) ||
        !checkdate(
            (int)substr($tanggal, 5, 2),
            (int)substr($tanggal, 8, 2),
            (int)substr($tanggal, 0, 4)
        )
    ) {
        $pesan = 'Periksa kembali judul, kategori, dan tanggal.';
    } else {
        $stmt = mysqli_prepare(
            $koneksi,
            "UPDATE pengumuman_sekolah
             SET judul = ?, isi = ?, kategori = ?,
                 tanggal_terbit = ?
             WHERE id_pengumuman = ?"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssssi",
            $judul,
            $isi,
            $kategori,
            $tanggal,
            $id
        );

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header('Location: index.php');
            exit;
        }

        $pesan = 'Gagal mengubah pengumuman.';
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pengumuman - InfoSekolah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h2>🎓 InfoSekolah</h2>
    <p>Sistem Informasi Pengumuman Siswa</p>
</div>

<div class="container">
    <div class="header">
        <h2>Edit Pengumuman</h2>
    </div>

    <div class="card">

        <?php if ($pesan !== '') { ?>
            <div class="alert"><?= aman($pesan) ?></div>
        <?php } ?>

        <form method="POST">
            <label for="judul">Judul Pengumuman</label>
            <input
                type="text"
                id="judul"
                name="judul"
                maxlength="100"
                value="<?= aman($judul) ?>"
                required
            >

            <label for="isi">Isi Pengumuman</label>
            <textarea id="isi" name="isi" required><?= aman($isi) ?></textarea>

            <label for="kategori">Kategori</label>
            <select id="kategori" name="kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <option value="Akademik"
                    <?= $kategori === 'Akademik' ? 'selected' : '' ?>>
                    Akademik
                </option>
                <option value="Kegiatan"
                    <?= $kategori === 'Kegiatan' ? 'selected' : '' ?>>
                    Kegiatan
                </option>
                <option value="Penting"
                    <?= $kategori === 'Penting' ? 'selected' : '' ?>>
                    Penting
                </option>
                <option value="Lainnya"
                    <?= $kategori === 'Lainnya' ? 'selected' : '' ?>>
                    Lainnya
                </option>
            </select>

            <label for="tanggal_terbit">Tanggal Terbit</label>
            <input
                type="date"
                id="tanggal_terbit"
                name="tanggal_terbit"
                value="<?= aman($tanggal) ?>"
                required
            >

            <button type="submit" class="btn btn-primary">
                Simpan Perubahan
            </button>

            <a href="index.php" class="btn btn-edit">
                Kembali
            </a>
        </form>

    </div>
</div>

</body>
</html>
